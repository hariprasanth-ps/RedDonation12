package com.RestAPI.APICRUDREST1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Apicrudrest1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
