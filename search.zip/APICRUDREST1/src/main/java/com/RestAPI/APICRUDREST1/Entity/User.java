package com.RestAPI.APICRUDREST1.Entity;




	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.Table;



	@Entity
	@Table(name = "users")
	public class User {



	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;



	@Column(name = "bookname")
	private String bookname;



	@Column(name = "author")
	private String author;



	@Column(name = "price")
	private String price;

	@Column(name = "edition")
	private String edition;

	public User() {



	}



	public User(String bookname, String author, String price, String edition) {
	super();
	this.bookname = bookname;
	this.author = author;
	this.price = price;
	this.edition=edition;
	}



	public long getId() {
	return id;
	}
	public void setId(long id) {
	this.id = id;
	}
	public String getbookname() {
	return bookname;
	}
	public void setbookname(String bookname) {
	this.bookname = bookname;
	}
	public String getauthor() {
	return author;
	}
	public void setauthor(String author) {
	this.author = author;
	}
	public String getEdition() {
		return edition;
	}



	public void setEdition(String edition) {
		this.edition = edition;
	}



	public String getprice() {
	return price;
	}
	public void setprice(String price) {
	this.price = price;
	}
	}

