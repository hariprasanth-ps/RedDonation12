package com.RestAPI.APICRUDREST1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apicrudrest1Application {

	public static void main(String[] args) {
		SpringApplication.run(Apicrudrest1Application.class, args);
	}

}
