package com.RestAPI.APICRUDREST1.repository;




import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;
import com.RestAPI.APICRUDREST1.Entity.User;
@Repository
public interface Userrepository extends JpaRepository<User, String>{

	Optional<User> findBybookname(String userbookname);

}

