package com.RestAPI.APICRUDREST1.Controller;


	import java.util.List;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;
	import com.RestAPI.APICRUDREST1.Entity.User;
	import com.RestAPI.APICRUDREST1.Exception.ResourceNotFoundException;
	import com.RestAPI.APICRUDREST1.repository.Userrepository;
	@RestController
	@RequestMapping("/api/users")
	public class UserController { @Autowired
	private Userrepository userrepository; // get all users
	@GetMapping
	public List < User > getAllUsers() {
	return this.userrepository.findAll();
	} // get user by id
	@GetMapping("/{bookname}")
	public User getUserBybookname(@PathVariable(value = "bookname") String userbookname) {
	return this.userrepository.findBybookname(userbookname).orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userbookname));
	}
	// create user
	@PostMapping
	public User createUser(@RequestBody User user) {
	return this.userrepository.save(user);
	} // update user
	@PutMapping("/{id}")
	public User updateUser(@RequestBody User user, @PathVariable("id") String userbookname) {
	User existingUser = this.userrepository.findBybookname(userbookname)
	.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userbookname));
	existingUser.setbookname(user.getbookname());
	existingUser.setauthor(user.getauthor());
	existingUser.setprice(user.getprice());
	existingUser.setEdition(user.getEdition());
	return this.userrepository.save(existingUser);
	}
	 //delete user by id
	@DeleteMapping("/{id}")
	public ResponseEntity < User > deleteUser(@PathVariable("id") String userbookname) {
	User existingUser = this.userrepository.findBybookname(userbookname)
	.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userbookname));
	this.userrepository.delete(existingUser);
	return ResponseEntity.ok().build();
	}
	}



